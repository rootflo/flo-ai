class FloMember():
    def __init__(self, name: str, type: str) -> None:
        self.name = name
        self.type = type
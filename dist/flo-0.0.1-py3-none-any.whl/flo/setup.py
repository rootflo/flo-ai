from setuptools import setup, find_packages

setup(
    name="flo",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],  # Add any dependencies here
    author="rootflo",
    author_email="",
    description="A easy way to create AI agents",
    url="https://github.com/aesy-engineering/flo",
)
